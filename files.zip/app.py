"""
app.py  —  FinanceOS  💸
══════════════════════════════════════════════════════════════════
Entry point.  Contains:
  • Page config + global CSS
  • Session-state defaults
  • Navigation helpers (go / nav / switch_mode)
  • Auth page
  • Onboarding pages
  • Sidebar + Topbar renderers
  • Tracker pages   (mode == "tracker" only)
  • Analyzer pages  (both modes)
  • Reports page
  • Profile page
  • Main router

All heavy calculations are delegated to core/:
  core/db.py              – SQLite CRUD
  core/tracker_engine.py  – DataFrame enrichment + caching
  core/analyzer_engine.py – read-only payload builders
  core/metrics.py         – reusable KPI functions
  core/insights.py        – HTML card builders
  core/charts.py          – Plotly figure factories
"""

import io
from datetime import date, datetime

import pandas as pd
import streamlit as st

from core.db import (
    db_add_txn,
    db_check_login,
    db_clear_txns,
    db_delete_budget,
    db_delete_txn,
    db_get_budgets,
    db_get_txns,
    db_has_transactions,
    db_import_txns,
    db_register,
    db_set_budget,
    db_update_txn,
    init_db,
)
from core.tracker_engine import (
    CATS,
    MONTHS,
    filter_df,
    get_df,
    invalidate_cache,
)
from core import analyzer_engine, insights

# ── Init ──────────────────────────────────────────────────────────
init_db()

# ══════════════════════════════════════════════════════════════════
#  PAGE CONFIG
# ══════════════════════════════════════════════════════════════════
st.set_page_config(
    page_title="FinanceOS",
    layout="wide",
    page_icon="💸",
    initial_sidebar_state="collapsed",
)

# ══════════════════════════════════════════════════════════════════
#  SESSION STATE
# ══════════════════════════════════════════════════════════════════
DEFAULTS = {
    "logged_in":   False,
    "username":    "",
    "app_page":    "auth",        # auth | onboard_upload | onboard_consent | platform
    "mode":        None,          # "tracker" | "analyzer"
    "nav_section": "analyzer",
    "nav_page":    "analytics",
    "edit_txn_id": None,
    "profile_open": False,
}
for k, v in DEFAULTS.items():
    if k not in st.session_state:
        st.session_state[k] = v


# ══════════════════════════════════════════════════════════════════
#  NAVIGATION HELPERS
# ══════════════════════════════════════════════════════════════════
def go(page: str, **kwargs) -> None:
    st.session_state.app_page = page
    for k, v in kwargs.items():
        st.session_state[k] = v
    st.rerun()


def nav(section: str, page: str) -> None:
    st.session_state.nav_section = section
    st.session_state.nav_page    = page
    st.rerun()


def switch_mode(new_mode: str) -> None:
    """Switch between tracker and analyzer modes, rerouting safely."""
    current_section = st.session_state.get("nav_section", "analyzer")
    st.session_state.mode = new_mode
    if new_mode == "analyzer" and current_section == "tracker":
        st.session_state.nav_section = "analyzer"
        st.session_state.nav_page    = "analytics"
    st.rerun()


# ══════════════════════════════════════════════════════════════════
#  GLOBAL BASE CSS
# ══════════════════════════════════════════════════════════════════
st.markdown("""
<style>
@import url('https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700;800;900&display=swap');

*, *::before, *::after { box-sizing: border-box; }

html, body, [data-testid="stAppViewContainer"],
[data-testid="stAppViewBlockContainer"], .main, .stApp {
    font-family: 'Nunito', sans-serif !important;
    color: #1A1A2E !important;
}
[data-testid="stHeader"] { background: transparent !important; }
[data-testid="stSidebar"] { display: none !important; }

h1 { color:#be185d!important; font-weight:900!important; font-size:2.2rem!important; }
h2 { color:#9d174d!important; font-weight:900!important; font-size:1.5rem!important;
     border-left:5px solid #F9A8D4; padding-left:10px; margin-top:.4rem; }
h3 { color:#7c3aed!important; font-weight:800!important; }

/* Metrics */
div[data-testid="metric-container"] {
    background:#FFFFFF!important; border:3px solid #F9A8D4!important;
    border-radius:20px!important; padding:20px 22px!important;
    box-shadow:0 6px 24px rgba(249,168,212,.25)!important; }
div[data-testid="metric-container"] [data-testid="stMetricLabel"],
div[data-testid="metric-container"] label p {
    color:#9d174d!important; font-weight:900!important; font-size:.76rem!important;
    letter-spacing:.09em!important; text-transform:uppercase!important; }
div[data-testid="metric-container"] [data-testid="stMetricValue"] div {
    color:#1A1A2E!important; font-size:1.7rem!important; font-weight:900!important;
    -webkit-text-fill-color:#1A1A2E!important; }

/* Alerts */
[data-testid="stAlert"] p, [data-testid="stAlert"] div {
    color:#1A1A2E!important; font-weight:800!important; font-size:1rem!important; }

/* Table / DataFrame */
[data-testid="stDataFrame"] { border-radius:14px; overflow:hidden; border:2px solid #A5F3FC; }

/* File uploader */
[data-testid="stFileUploader"] { background:#FFF0F9; border-radius:18px;
    border:2.5px dashed #F9A8D4; padding:1rem; }

/* ALL buttons — pink-purple gradient */
[data-testid="baseButton-secondary"],[data-testid="baseButton-primary"],
[data-testid="stDownloadButton"] button,[data-testid="stFileUploader"] button,
button[kind="secondary"],button[kind="primary"] {
    background: linear-gradient(90deg,#f472b6,#a78bfa)!important;
    color:#FFFFFF!important; -webkit-text-fill-color:#FFFFFF!important;
    border-radius:14px!important; border:none!important;
    font-weight:900!important; font-size:1rem!important; padding:.6rem 1.4rem!important; }
[data-testid="baseButton-secondary"]:hover,
[data-testid="stDownloadButton"] button:hover {
    background:linear-gradient(90deg,#ec4899,#8b5cf6)!important; }

/* Inputs */
input[type="text"],input[type="password"],input[type="number"],
[data-testid="stTextInput"] input,[data-testid="stNumberInput"] input {
    border:2px solid #F9A8D4!important; border-radius:12px!important;
    font-family:'Nunito',sans-serif!important; font-weight:700!important;
    color:#1A1A2E!important; background:#FFFBFB!important; }

hr  { border-color:#F9A8D4; opacity:.5; }
.block-container { padding-top:0!important; padding-bottom:2rem; max-width:100%!important; }

/* ── Platform sidebar nav ──────────────────────────────── */
.nav-section-label {
    font-size:.63rem; font-weight:900; letter-spacing:.14em; text-transform:uppercase;
    color:#be185d; padding:10px 10px 3px; margin-top:.6rem; }
.nav-item {
    display:flex; align-items:center; gap:10px; padding:9px 14px;
    border-radius:12px; cursor:pointer; font-weight:700; font-size:.91rem;
    color:#374151; margin:2px 0; transition:all .15s; border:none;
    background:transparent; width:100%; text-align:left; }
.nav-item:hover { background:rgba(249,168,212,.25); color:#be185d; }
.nav-item.active {
    background:linear-gradient(90deg,rgba(244,114,182,.18),rgba(167,139,250,.18));
    color:#be185d; border-left:3px solid #f472b6; padding-left:11px; font-weight:900; }

/* ── KPI cards ──────────────────────────────────────────── */
.kpi-card { background:#FFFFFF; border-radius:20px; padding:20px 22px;
    box-shadow:0 6px 24px rgba(0,0,0,.06); }
.kpi-label { font-size:.72rem; font-weight:900; letter-spacing:.09em;
    text-transform:uppercase; color:#9d174d; margin-bottom:6px; }
.kpi-value { font-size:1.7rem; font-weight:900; color:#1A1A2E; }

/* ── Page topbar ────────────────────────────────────────── */
.page-topbar { display:flex; align-items:center; justify-content:space-between;
    margin-bottom:1.5rem; padding-bottom:1rem; border-bottom:2px solid #F9A8D4; }
.page-title  { font-size:1.9rem; font-weight:900; color:#be185d; margin:0; }
.page-breadcrumb { font-size:.82rem; font-weight:700; color:#9d174d; opacity:.7; }

/* ── Auth page full-viewport centering ──────────────────── */
.auth-viewport {
    position: fixed; top:0; left:0; right:0; bottom:0;
    display:flex; flex-direction:column;
    align-items:center; justify-content:center;
    background:linear-gradient(150deg,#FFF0F9 0%,#EFF6FF 50%,#F0FDF4 100%);
    overflow-y: auto; padding: 1rem;
}

/* ── Onboarding page ────────────────────────────────────── */
.onboard-viewport {
    min-height: 100vh;
    background: linear-gradient(135deg,#EDE9FE 0%,#FFF0F9 45%,#ECFDF5 100%);
}

/* ── Platform sticky topbar ─────────────────────────────── */
.finance-topbar {
    position: sticky; top: 0; z-index: 999;
    display: flex; align-items: center; justify-content: space-between;
    padding: .7rem 1.8rem;
    background: rgba(255,240,249,.82);
    backdrop-filter: blur(14px); -webkit-backdrop-filter: blur(14px);
    border-bottom: 2px solid rgba(249,168,212,.45);
    box-shadow: 0 4px 24px rgba(249,168,212,.18);
    border-radius: 0 0 18px 18px;
    margin-bottom: 1.2rem;
}
.topbar-logo {
    font-size: 1.22rem; font-weight: 900; color: #be185d;
    letter-spacing: -.02em; display: flex; align-items: center; gap: 6px;
}
.topbar-center { display: flex; align-items: center; gap: 10px; }
.topbar-right  { display: flex; align-items: center; gap: 12px; }

/* mode badge pill */
.mode-badge {
    display: inline-flex; align-items: center;
    background: rgba(255,255,255,.75);
    border: 2px solid rgba(249,168,212,.5);
    border-radius: 50px; padding: 4px 12px;
    font-size: .78rem; font-weight: 900; color: #9d174d;
    box-shadow: 0 2px 10px rgba(249,168,212,.2);
}

/* profile chip */
.profile-chip {
    display: flex; align-items: center; gap: 7px; cursor: pointer;
    background: rgba(255,255,255,.7);
    border: 2px solid rgba(249,168,212,.4);
    border-radius: 50px; padding: 5px 14px 5px 6px;
    font-weight: 800; font-size: .88rem; color: #9d174d;
}
.profile-avatar {
    width: 28px; height: 28px; border-radius: 50%;
    background: linear-gradient(135deg,#f472b6,#a78bfa);
    color: #fff; font-weight: 900; font-size: .88rem;
    display: flex; align-items: center; justify-content: center;
}

/* topbar page title */
.topbar-page-title {
    font-size: 1rem; font-weight: 800; color: #7c3aed;
}
</style>""", unsafe_allow_html=True)


# ══════════════════════════════════════════════════════════════════
#  UI HELPERS  (HTML card factories, shared across pages)
# ══════════════════════════════════════════════════════════════════

def kpi(label, value, border="#F9A8D4", shadow="rgba(249,168,212,.3)"):
    return f"""<div style="background:#FFFFFF;border:3px solid {border};border-radius:20px;
        padding:20px 22px;box-shadow:0 6px 24px {shadow};">
        <div style="color:#9d174d;font-weight:900;font-size:.72rem;letter-spacing:.09em;
            text-transform:uppercase;margin-bottom:6px;">{label}</div>
        <div style="color:#1A1A2E;font-weight:900;font-size:1.7rem;font-family:Nunito,sans-serif;">{value}</div>
    </div>"""


def info_card(label, value, border="#6EE7B7", shadow="rgba(110,231,183,.25)"):
    return f"""<div style="background:#FFFFFF;border:3px solid {border};border-radius:20px;
        padding:18px 22px;box-shadow:0 6px 24px {shadow};">
        <div style="color:#9d174d;font-weight:900;font-size:.72rem;text-transform:uppercase;margin-bottom:6px;">{label}</div>
        <div style="color:#1A1A2E;font-weight:900;font-size:1.35rem;">{value}</div>
    </div>"""


def empty_state(icon, title, subtitle):
    st.markdown(f"""<div style="background:#FFFFFF;border:3px dashed #F9A8D4;border-radius:22px;
        padding:50px;text-align:center;margin:2rem 0;">
        <div style="font-size:3rem;">{icon}</div>
        <div style="font-size:1.2rem;font-weight:900;color:#9d174d;margin-top:1rem;">{title}</div>
        <div style="color:#6b7280;font-weight:700;margin-top:.5rem;">{subtitle}</div>
    </div>""", unsafe_allow_html=True)


def page_header(title, breadcrumb=""):
    st.markdown(f"""<div class="page-topbar">
        <div>
            <div class="page-breadcrumb">{breadcrumb}</div>
            <div class="page-title">{title}</div>
        </div>
    </div>""", unsafe_allow_html=True)


# ══════════════════════════════════════════════════════════════════
#  TOPBAR
# ══════════════════════════════════════════════════════════════════

def _current_page_title() -> str:
    PAGE_TITLES = {
        "analytics":  "📈 Analytics",
        "insights":   "💡 Insights",
        "health":     "🏥 Financial Health",
        "charts":     "📊 Charts",
        "savings":    "💚 Savings Trends",
        "categories": "🏷️ Category Analysis",
        "overview":   "🏠 Overview",
        "add":        "➕ Add Transaction",
        "edit":       "✏️ Edit / Delete",
        "budgets":    "💰 Budgets",
        "history":    "📋 History",
        "download":   "📥 Download Report",
        "profile":    "👤 Profile",
    }
    return PAGE_TITLES.get(st.session_state.get("nav_page", "analytics"), "📈 Analytics")


def render_topbar():
    uid        = st.session_state.username
    mode       = st.session_state.get("mode", "tracker")
    page_title = _current_page_title()
    avatar_letter = uid[0].upper() if uid else "U"
    mode_label = "📝 Tracker+Analyzer" if mode == "tracker" else "📊 Analyzer Only"

    st.markdown(f"""
    <div class="finance-topbar">
        <div class="topbar-logo">
            💸 <span style="color:#7c3aed;">FinanceOS</span>
            <span class="topbar-page-title" style="margin-left:14px;padding-left:14px;
                border-left:2px solid rgba(249,168,212,.4);">{page_title}</span>
        </div>
        <div class="topbar-center">
            <span style="font-size:.74rem;font-weight:900;color:#9d174d;
                letter-spacing:.08em;text-transform:uppercase;margin-right:2px;">MODE</span>
        </div>
        <div class="topbar-right">
            <span class="mode-badge">{mode_label}</span>
            <div class="profile-chip">
                <div class="profile-avatar">{avatar_letter}</div>
                {uid}
            </div>
        </div>
    </div>
    """, unsafe_allow_html=True)

    _, tcol2, tcol3, tcol4, tcol5 = st.columns([2, 1.2, 1.2, 1, 1])
    with tcol2:
        if st.button(
            "📝 Tracker ✓" if mode == "tracker" else "📝 Tracker",
            key="topbar_mode_tracker",
            use_container_width=True,
            type="primary" if mode == "tracker" else "secondary",
        ):
            if mode != "tracker":
                switch_mode("tracker")
    with tcol3:
        if st.button(
            "📊 Analyzer ✓" if mode == "analyzer" else "📊 Analyzer",
            key="topbar_mode_analyzer",
            use_container_width=True,
            type="primary" if mode == "analyzer" else "secondary",
        ):
            if mode != "analyzer":
                switch_mode("analyzer")
    with tcol4:
        if st.button("👤 Profile", key="topbar_to_profile", use_container_width=True):
            nav("profile", "profile")
    with tcol5:
        if st.button("🚪 Logout", key="topbar_logout", use_container_width=True):
            for k in list(DEFAULTS.keys()):
                st.session_state[k] = DEFAULTS[k]
            st.rerun()


# ══════════════════════════════════════════════════════════════════
#  SIDEBAR
# ══════════════════════════════════════════════════════════════════

def render_sidebar():
    mode = st.session_state.get("mode", "tracker")

    st.markdown("""<style>
    [data-testid="stSidebar"] { display:flex!important; }
    [data-testid="stSidebar"] > div:first-child {
        background:linear-gradient(180deg,#FFF0F9 0%,#EFF6FF 100%);
        border-right:2px solid #F9A8D4; padding:1rem .7rem; }
    </style>""", unsafe_allow_html=True)

    with st.sidebar:
        st.markdown("""<div style="font-size:1.35rem;font-weight:900;color:#be185d;
            padding:6px 0 14px;border-bottom:2px solid #F9A8D4;margin-bottom:.6rem;
            letter-spacing:-.02em;">💸 FinanceOS</div>""", unsafe_allow_html=True)

        st.markdown(f"""<div style="background:linear-gradient(135deg,#FFF0F9,#EFF6FF);
            border:2px solid #F9A8D4;border-radius:14px;padding:10px 12px;
            font-size:.82rem;font-weight:800;color:#9d174d;margin-bottom:.8rem;">
            👤 Logged in as<br>
            <span style="font-size:1rem;color:#be185d;">{st.session_state.username}</span>
        </div>""", unsafe_allow_html=True)

        # ── ANALYZER (always visible) ─────────────────────────
        st.markdown('<div class="nav-section-label">📊 Analyzer</div>', unsafe_allow_html=True)
        for label, pg in [
            ("📈 Analytics",        "analytics"),
            ("💡 Insights",         "insights"),
            ("🏥 Financial Health", "health"),
            ("📊 Charts",           "charts"),
            ("💚 Savings Trends",   "savings"),
            ("🏷️ Category Analysis","categories"),
        ]:
            if st.button(label, key=f"nav_a_{pg}", use_container_width=True):
                nav("analyzer", pg)

        # ── TRACKER (tracker mode only) ───────────────────────
        if mode == "tracker":
            st.markdown('<div class="nav-section-label">📝 Tracker</div>', unsafe_allow_html=True)
            for label, pg in [
                ("🏠 Overview",        "overview"),
                ("➕ Add Transaction", "add"),
                ("✏️ Edit / Delete",    "edit"),
                ("💰 Monthly Budgets", "budgets"),
                ("📋 History",         "history"),
            ]:
                if st.button(label, key=f"nav_t_{pg}", use_container_width=True):
                    nav("tracker", pg)

        # ── REPORTS ───────────────────────────────────────────
        st.markdown('<div class="nav-section-label">📥 Reports</div>', unsafe_allow_html=True)
        if st.button("📥 Download Report", key="nav_r_download", use_container_width=True):
            nav("reports", "download")

        # ── PROFILE ───────────────────────────────────────────
        st.markdown('<div class="nav-section-label">👤 Profile</div>', unsafe_allow_html=True)
        if st.button("👤 My Profile", key="nav_p_profile", use_container_width=True):
            nav("profile", "profile")

        st.markdown("---")
        st.markdown(f"""<div style="background:#FFF0F9;border:1.5px solid #F9A8D4;border-radius:12px;
            padding:8px 10px;font-size:.75rem;font-weight:800;color:#9d174d;margin-bottom:.5rem;">
            Use the <b>topbar</b> to switch modes instantly.
        </div>""", unsafe_allow_html=True)
        if st.button("🚪 Logout", use_container_width=True, key="sidebar_logout_btn"):
            for k in list(DEFAULTS.keys()):
                st.session_state[k] = DEFAULTS[k]
            st.rerun()


# ══════════════════════════════════════════════════════════════════
#  AUTH PAGE
# ══════════════════════════════════════════════════════════════════

def page_auth():
    st.markdown("""<style>
    html, body, .stApp,
    [data-testid="stAppViewContainer"],
    [data-testid="stAppViewBlockContainer"], .main {
        background: linear-gradient(150deg,#FFF0F9 0%,#EFF6FF 50%,#F0FDF4 100%) !important;
        overflow: hidden !important;
    }
    .block-container {
        padding: 0 !important; max-width: 100% !important;
        height: 100vh !important; display: flex !important;
        flex-direction: column !important; align-items: center !important;
        justify-content: center !important;
    }
    [data-testid="stSidebar"] { display: none !important; }
    [data-testid="stRadio"] > div { gap: 4px !important; }
    [data-testid="stRadio"] label { font-size: .93rem !important; font-weight: 800 !important; }
    [data-testid="stTextInput"] label p { font-size: .82rem !important; font-weight: 800 !important; margin-bottom: 2px !important; }
    div[data-testid="stVerticalBlock"] { gap: 0.4rem !important; }
    </style>""", unsafe_allow_html=True)

    st.markdown("""
    <div style="width:100%;display:flex;flex-direction:column;
        align-items:center;justify-content:center;padding:0;">
    """, unsafe_allow_html=True)

    st.markdown("""
    <div style="text-align:center;margin-bottom:1.4rem;">
        <div style="font-size:3rem;line-height:1;">💸</div>
        <div style="font-size:2.4rem;font-weight:900;line-height:1.1;
            background:linear-gradient(90deg,#be185d,#7c3aed);
            -webkit-background-clip:text;-webkit-text-fill-color:transparent;">
            FinanceOS</div>
        <div style="color:#9d174d;font-weight:700;font-size:.85rem;margin-top:4px;
            letter-spacing:.1em;">TRACK · ANALYSE · GROW</div>
    </div>
    <style>
    @keyframes fadeInUp {
        from { opacity:0; transform:translateY(20px); }
        to   { opacity:1; transform:translateY(0); }
    }
    </style>
    """, unsafe_allow_html=True)

    _, col, _ = st.columns([1, 1.5, 1])
    with col:
        st.markdown("""<div style="background:#FFFFFF;border:3px solid #F9A8D4;
            border-radius:24px;padding:28px 32px 24px;
            box-shadow:0 20px 60px rgba(249,168,212,.28);
            animation:fadeInUp .5s ease;">
        """, unsafe_allow_html=True)

        tab = st.radio("", ["🔐 Login", "✨ Sign Up"], horizontal=True, key="auth_tab",
                       label_visibility="collapsed")
        st.markdown("<div style='height:6px'></div>", unsafe_allow_html=True)

        if tab == "🔐 Login":
            uid = st.text_input("User ID", placeholder="e.g. admin", key="l_uid")
            pwd = st.text_input("Password", type="password", key="l_pwd")
            st.markdown("<div style='height:4px'></div>", unsafe_allow_html=True)
            if st.button("Login  →", use_container_width=True, key="login_btn"):
                u = uid.strip()
                if not u or not pwd:
                    st.error("Please fill in both fields.")
                elif db_check_login(u, pwd):
                    st.session_state.logged_in = True
                    st.session_state.username  = u
                    if db_has_transactions(u):
                        st.session_state.mode = st.session_state.get("mode") or "tracker"
                        go("platform", nav_section="analyzer", nav_page="analytics")
                    else:
                        go("onboard_upload")
                else:
                    st.error("❌ Invalid credentials. Please try again.")

            st.markdown("""
            <div style="background:#FFF0F9;border:2px dashed #F9A8D4;border-radius:10px;
                padding:8px 12px;margin-top:.6rem;font-size:.8rem;color:#9d174d;font-weight:700;">
                🧪 <b>Demo:</b>&nbsp; admin / admin123 &nbsp;·&nbsp; demo / demo
            </div>""", unsafe_allow_html=True)

        else:
            new_uid  = st.text_input("Choose a User ID",  key="su_uid")
            new_pwd  = st.text_input("Choose a Password", type="password", key="su_pwd")
            new_pwd2 = st.text_input("Confirm Password",  type="password", key="su_pwd2")
            st.markdown("<div style='height:4px'></div>", unsafe_allow_html=True)
            if st.button("Create Account  →", use_container_width=True, key="signup_btn"):
                if not new_uid.strip() or not new_pwd:
                    st.error("Fill in all fields.")
                elif new_pwd != new_pwd2:
                    st.error("Passwords don't match.")
                elif len(new_pwd) < 4:
                    st.error("Password must be at least 4 characters.")
                else:
                    ok, msg = db_register(new_uid.strip(), new_pwd)
                    if ok:
                        st.session_state.logged_in = True
                        st.session_state.username  = new_uid.strip()
                        go("onboard_upload")
                    else:
                        st.error(msg)

        st.markdown("</div>", unsafe_allow_html=True)
    st.markdown("</div>", unsafe_allow_html=True)


# ══════════════════════════════════════════════════════════════════
#  ONBOARDING
# ══════════════════════════════════════════════════════════════════

def _onboard_chrome(step_num: int, step_label: str):
    username = st.session_state.username
    pct = {1: 40, 2: 75, 3: 100}.get(step_num, 40)
    st.markdown(f"""<style>
    html,body,.stApp,[data-testid="stAppViewContainer"],
    [data-testid="stAppViewBlockContainer"],.main {{
        background:linear-gradient(135deg,#EDE9FE 0%,#FFF0F9 45%,#ECFDF5 100%)!important; }}
    .block-container {{ padding:0!important; max-width:100%!important; }}
    [data-testid="stSidebar"] {{ display:none!important; }}
    </style>
    <div style="position:fixed;top:0;left:0;right:0;height:5px;background:#f3e8ff;z-index:9999;">
      <div style="height:5px;background:linear-gradient(90deg,#f472b6,#a78bfa);
          width:{pct}%;transition:width .5s ease;border-radius:0 3px 3px 0;"></div>
    </div>
    <div style="display:flex;align-items:center;justify-content:space-between;
        padding:1.1rem 2.5rem .9rem;border-bottom:2px solid #e9d5ff;
        background:rgba(255,255,255,.55);backdrop-filter:blur(8px);
        margin-bottom:0;position:sticky;top:0;z-index:100;">
      <div style="font-size:1.1rem;font-weight:900;color:#7c3aed;">
          💸 <span style="color:#be185d;">FinanceOS</span>
      </div>
      <div style="display:flex;align-items:center;gap:20px;">
          <div style="font-size:.78rem;font-weight:800;color:#a78bfa;letter-spacing:.08em;">
              ACCOUNT SETUP &nbsp;·&nbsp; Step {step_num} of 2
          </div>
          <div style="font-size:.8rem;font-weight:800;color:#9d174d;
              background:#FFF0F9;border:2px solid #F9A8D4;border-radius:20px;padding:4px 14px;">
              👤 {username}
          </div>
      </div>
    </div>
    <div style="height:2rem;"></div>
    """, unsafe_allow_html=True)


def page_onboard_upload():
    _onboard_chrome(1, "Upload Data")
    _, col, _ = st.columns([1, 2.2, 1])
    with col:
        st.markdown("""
        <div style="background:#FFFFFF;border:3px solid #93C5FD;border-radius:28px;
            padding:40px 44px 36px;box-shadow:0 24px 64px rgba(147,197,253,.22);
            animation:fadeInUp .5s ease;">
            <div style="text-align:center;margin-bottom:1.5rem;">
                <div style="font-size:3rem;line-height:1;">📊</div>
                <div style="font-size:1.55rem;font-weight:900;color:#1d4ed8;margin-top:.5rem;">
                    Import Your Finance Data</div>
                <div style="color:#6b7280;font-weight:700;font-size:.92rem;margin-top:.4rem;">
                    Upload your Excel file to get started — your data is saved permanently in the database.</div>
            </div>
            <div style="background:#EFF6FF;border:2px dashed #93C5FD;border-radius:12px;
                padding:11px 16px;margin-bottom:1.2rem;font-weight:700;
                color:#1e40af;font-size:.86rem;">
                📋 <b>Required columns:</b>&nbsp;
                Date &nbsp;·&nbsp; Transaction Type (credit/debit) &nbsp;·&nbsp;
                Category &nbsp;·&nbsp; Amount &nbsp;·&nbsp; Account Name
            </div>
        </div>
        <style>@keyframes fadeInUp{from{opacity:0;transform:translateY(18px)}to{opacity:1;transform:none}}</style>
        """, unsafe_allow_html=True)

        upload_file = st.file_uploader(
            "Upload Excel file (.xlsx)", type=["xlsx"], key="onboard_upload_file"
        )
        if upload_file:
            try:
                udf = pd.read_excel(upload_file)
                udf.columns = udf.columns.str.strip()
                missing = [c for c in ["Date","Transaction Type","Category","Amount"]
                           if c not in udf.columns]
                if missing:
                    st.error(f"❌ Missing required columns: {', '.join(missing)}")
                else:
                    if "Account Name" not in udf.columns:
                        udf["Account Name"] = "Uploaded"
                    st.success(f"✅ Loaded **{len(udf)}** rows from **{upload_file.name}**")
                    st.dataframe(udf.head(8), use_container_width=True)
                    if st.button("💾  Save to Database & Continue →",
                                 use_container_width=True, key="onboard_do_import"):
                        count = db_import_txns(st.session_state.username, udf)
                        invalidate_cache()
                        st.success(f"✅ {count} transactions saved!")
                        go("onboard_consent")
            except Exception as e:
                st.error(f"Could not read file: {e}")
        else:
            st.markdown("""
            <div style="background:#FFF0F9;border:2.5px dashed #F9A8D4;border-radius:16px;
                padding:28px;text-align:center;margin-top:.5rem;">
                <div style="font-size:2.2rem;">📂</div>
                <div style="font-weight:800;color:#9d174d;margin-top:.5rem;font-size:.95rem;">
                    No file uploaded yet</div>
                <div style="color:#6b7280;font-weight:700;font-size:.82rem;margin-top:.3rem;">
                    An Excel file is required to continue.</div>
            </div>
            """, unsafe_allow_html=True)


def page_onboard_consent():
    _onboard_chrome(2, "Choose Your Mode")
    username = st.session_state.username
    _, col, _ = st.columns([1, 2.4, 1])
    with col:
        st.markdown(f"""
        <div style="background:#FFFFFF;border:3px solid #c4b5fd;border-radius:28px;
            padding:40px 44px 32px;box-shadow:0 24px 64px rgba(167,139,250,.22);">
            <div style="text-align:center;margin-bottom:1.8rem;">
                <div style="font-size:3rem;line-height:1;">🎯</div>
                <div style="font-size:1.55rem;font-weight:900;color:#1A1A2E;margin-top:.6rem;">
                    How would you like to use FinanceOS,
                    <span style="color:#be185d;">{username}</span>?
                </div>
                <div style="color:#6b7280;font-weight:700;font-size:.93rem;margin-top:.5rem;">
                    Your data is already imported. Now choose your experience.
                </div>
            </div>
        </div>
        """, unsafe_allow_html=True)

        st.markdown("<div style='height:.75rem'></div>", unsafe_allow_html=True)
        c1, c2 = st.columns(2)

        with c1:
            st.markdown("""
            <div style="background:linear-gradient(135deg,#FFF0F9,#fce7f3);
                border:3px solid #F9A8D4;border-radius:20px;padding:24px;
                text-align:center;box-shadow:0 8px 24px rgba(249,168,212,.28);
                margin-bottom:.6rem;">
                <div style="font-size:2.6rem;">🗂️</div>
                <div style="font-weight:900;color:#be185d;font-size:1.2rem;margin-top:.6rem;">YES</div>
                <div style="color:#9d174d;font-size:.83rem;font-weight:700;margin-top:4px;">
                    Enable Tracker + Analyzer</div>
                <div style="margin-top:10px;font-size:.79rem;color:#6b7280;font-weight:700;line-height:1.5;">
                    ✅ Add &amp; edit transactions<br>✅ Set monthly budgets<br>
                    ✅ Full analytics &amp; insights<br>✅ Financial health score
                </div>
            </div>""", unsafe_allow_html=True)
            if st.button("✅  YES — Enable Tracker + Analyzer",
                         use_container_width=True, key="consent_yes"):
                st.session_state.mode = "tracker"
                go("platform", nav_section="tracker", nav_page="overview")

        with c2:
            st.markdown("""
            <div style="background:linear-gradient(135deg,#EFF6FF,#dbeafe);
                border:3px solid #93C5FD;border-radius:20px;padding:24px;
                text-align:center;box-shadow:0 8px 24px rgba(147,197,253,.28);
                margin-bottom:.6rem;">
                <div style="font-size:2.6rem;">📊</div>
                <div style="font-weight:900;color:#1d4ed8;font-size:1.2rem;margin-top:.6rem;">NO</div>
                <div style="color:#1e40af;font-size:.83rem;font-weight:700;margin-top:4px;">
                    Analyzer Only</div>
                <div style="margin-top:10px;font-size:.79rem;color:#6b7280;font-weight:700;line-height:1.5;">
                    ✅ Analytics &amp; charts<br>✅ Insights &amp; trends<br>
                    ✅ Download reports<br>❌ No manual tracking
                </div>
            </div>""", unsafe_allow_html=True)
            if st.button("📊  NO — Analyzer Only",
                         use_container_width=True, key="consent_no"):
                st.session_state.mode = "analyzer"
                go("platform", nav_section="analyzer", nav_page="analytics")

        st.markdown("""
        <div style="background:#FFFBEB;border:2px solid #FCD34D;border-radius:12px;
            padding:10px 16px;font-size:.82rem;font-weight:700;color:#92400e;text-align:center;">
            💡 You can switch modes anytime from the <b>topbar</b> switcher.
        </div>
        """, unsafe_allow_html=True)


# ══════════════════════════════════════════════════════════════════
#  ANALYZER PAGES  (read-only — both modes see these)
# ══════════════════════════════════════════════════════════════════

def pf_analytics():
    page_header("📈 Analytics", "Analyzer › Analytics")
    df = get_df()
    if df.empty:
        empty_state("📊", "No data to analyse",
                    "Add transactions from the Tracker, or reimport an Excel file from Profile.")
        return

    c1, c2 = st.columns(2)
    with c1:
        view = st.selectbox("View By", ["Monthly", "Yearly"], key="an_view")
    with c2:
        if view == "Monthly":
            months = sorted(df["Month Name"].dropna().unique().tolist())
            sel = st.selectbox("Select Month", ["All"] + months, key="an_month")
            cdf = df if sel == "All" else df[df["Month Name"] == sel]
        else:
            years = sorted(df["Year"].dropna().unique().tolist())
            sel = st.selectbox("Select Year", ["All"] + years, key="an_year")
            cdf = df if sel == "All" else df[df["Year"] == sel]

    payload = analyzer_engine.build_analytics_payload(cdf)
    sr = payload["kpis"]

    st.markdown(f"""<div style="display:grid;grid-template-columns:repeat(4,1fr);gap:16px;margin:1rem 0 1.5rem;">
        {kpi("💰 Income",  f"₹{sr['income']:,.0f}","#F9A8D4","rgba(249,168,212,.3)")}
        {kpi("💸 Expense", f"₹{sr['expenses']:,.0f}","#FCA5A5","rgba(252,165,165,.3)")}
        {kpi("🏦 Savings", f'₹{sr["net"]:,.0f}<span style="font-size:.9rem;color:{sr["direction_color"]}"> {sr["direction"]}</span>',
              "#6EE7B7","rgba(110,231,183,.3)")}
        {kpi("📊 Rate",    f"{sr['savings_pct']:.1f}%","#C4B5FD","rgba(196,181,253,.3)")}
    </div>""", unsafe_allow_html=True)

    figs = payload["figures"]
    st.markdown("---")
    st.subheader("🛍️ Top Expense Categories")
    if "bar_categories" in figs:
        st.plotly_chart(figs["bar_categories"], use_container_width=True,
                        config={"displayModeBar": False})
    if "pie_distribution" in figs:
        st.plotly_chart(figs["pie_distribution"], use_container_width=True,
                        config={"displayModeBar": False})

    st.markdown("---")
    st.subheader("📈 Monthly Expense Trend")
    if "line_trend" in figs:
        st.plotly_chart(figs["line_trend"], use_container_width=True,
                        config={"displayModeBar": False})


def pf_insights():
    page_header("💡 Insights", "Analyzer › Insights")
    df = get_df()
    if df.empty:
        empty_state("💡", "No data yet", "Add transactions or import an Excel file.")
        return

    payload = analyzer_engine.build_insights_payload(df)
    ins     = payload["insight_cards"]

    st.markdown(f"""<div style="display:grid;grid-template-columns:repeat(2,1fr);gap:20px;margin:1rem 0;">
        {info_card("🏆 Highest Spending Category", ins["top_category"], "#6EE7B7","rgba(110,231,183,.25)")}
        {info_card("🏧 Most Used Account",         ins["most_used_account"], "#93C5FD","rgba(147,197,253,.25)")}
        {info_card("📊 Total Transactions",         str(ins["total_transactions"]), "#C4B5FD","rgba(196,181,253,.25)")}
        {info_card("📅 Best Savings Month",         ins["best_savings_month"], "#F9A8D4","rgba(249,168,212,.25)")}
    </div>""", unsafe_allow_html=True)

    st.markdown("---")
    st.subheader("🤖 Smart Tip")
    st.markdown(payload["tip_html"], unsafe_allow_html=True)

    st.markdown("---")
    st.subheader("📋 Category Breakdown")
    bd = payload["breakdown_df"]
    if not bd.empty:
        st.dataframe(bd.sort_values("Total (₹)", ascending=False), use_container_width=True)


def pf_health():
    page_header("🏥 Financial Health", "Analyzer › Health Score")
    df = get_df()
    if df.empty:
        empty_state("🏥", "No data yet", "Add some transactions to see your health score.")
        return

    payload = analyzer_engine.build_health_payload(df)
    st.markdown(payload["status_html"], unsafe_allow_html=True)
    st.plotly_chart(payload["gauge_fig"], use_container_width=True,
                    config={"displayModeBar": False})

    sr = payload["kpis"]
    st.markdown("---")
    st.subheader("📊 Income vs Expense Breakdown")
    st.markdown(f"""<div style="display:grid;grid-template-columns:repeat(3,1fr);gap:16px;margin:1rem 0;">
        {kpi("💰 Total Income",  f"₹{sr['income']:,.0f}","#F9A8D4","rgba(249,168,212,.3)")}
        {kpi("💸 Total Expense", f"₹{sr['expenses']:,.0f}","#FCA5A5","rgba(252,165,165,.3)")}
        {kpi("🏦 Net Savings",   f"₹{sr['net']:,.0f}","#6EE7B7","rgba(110,231,183,.3)")}
    </div>""", unsafe_allow_html=True)


def pf_charts():
    page_header("📊 Charts", "Analyzer › Charts")
    df = get_df()
    if df.empty:
        empty_state("📊", "No data yet", "Start adding transactions to see charts.")
        return

    payload = analyzer_engine.build_charts_payload(df)
    figs    = payload["figures"]

    tab1, tab2, tab3 = st.tabs(["Income vs Expense", "Account Breakdown", "Category Trends"])
    with tab1:
        if "inc_exp" in figs:
            st.plotly_chart(figs["inc_exp"], use_container_width=True,
                            config={"displayModeBar": False})
    with tab2:
        if "account" in figs:
            st.plotly_chart(figs["account"], use_container_width=True,
                            config={"displayModeBar": False})
    with tab3:
        if "cat_month" in figs:
            st.plotly_chart(figs["cat_month"], use_container_width=True,
                            config={"displayModeBar": False})


def pf_savings():
    page_header("💚 Savings Trends", "Analyzer › Savings Trends")
    df = get_df()
    if df.empty:
        empty_state("💚", "No data yet", "Add transactions to view savings trends.")
        return

    payload = analyzer_engine.build_savings_payload(df)
    figs    = payload["figures"]
    if "bar" in figs:
        st.plotly_chart(figs["bar"], use_container_width=True,
                        config={"displayModeBar": False})
    if "line" in figs:
        st.plotly_chart(figs["line"], use_container_width=True,
                        config={"displayModeBar": False})


def pf_categories():
    page_header("🏷️ Category Analysis", "Analyzer › Category Analysis")
    df = get_df()
    if df.empty:
        empty_state("🏷️", "No data yet", "Add transactions to see category analysis.")
        return
    if df[df["Transaction Type"] == "debit"].empty:
        st.info("No expense transactions found.")
        return

    payload = analyzer_engine.build_categories_payload(df)
    bd      = payload["breakdown_df"]

    st.subheader("📋 Full Category Breakdown")
    st.dataframe(bd, use_container_width=True)

    st.markdown("---")
    if payload["treemap_fig"]:
        st.plotly_chart(payload["treemap_fig"], use_container_width=True,
                        config={"displayModeBar": False})


# ══════════════════════════════════════════════════════════════════
#  TRACKER PAGES  (tracker mode only — write-enabled)
# ══════════════════════════════════════════════════════════════════

def pf_overview():
    page_header("🏠 Tracker Overview", "Tracker › Overview")
    uid = st.session_state.username
    df  = get_df()
    if df.empty:
        empty_state("📭", "No transactions yet!",
                    "Use ➕ Add Transaction in the Tracker menu to get started.")
        return

    from core.metrics import calculate_savings_rate
    sr    = calculate_savings_rate(df)
    s_col = sr["direction_color"]
    s_ico = sr["direction"]

    st.markdown(f"""<div style="display:grid;grid-template-columns:repeat(4,1fr);gap:18px;margin:1rem 0 1.5rem;">
        {kpi("💰 Total Income",  f"₹{sr['income']:,.2f}","#F9A8D4","rgba(249,168,212,.3)")}
        {kpi("💸 Total Expense", f"₹{sr['expenses']:,.2f}","#FCA5A5","rgba(252,165,165,.3)")}
        {kpi("🏦 Net Savings",   f'₹{sr["net"]:,.2f}<span style="font-size:.9rem;color:{s_col}"> {s_ico}</span>',
              "#6EE7B7","rgba(110,231,183,.3)")}
        {kpi("📊 Savings Rate",  f"{sr['savings_pct']:.1f}%","#C4B5FD","rgba(196,181,253,.3)")}
    </div>""", unsafe_allow_html=True)

    cur_month = date.today().strftime("%Y-%m")
    budgets   = db_get_budgets(uid, cur_month)
    if not budgets.empty:
        st.markdown("---")
        st.subheader(f"💰 Budget Progress — {date.today().strftime('%B %Y')}")
        month_exp = df[(df["Transaction Type"] == "debit") & (df["Month Key"] == cur_month)]
        cat_spent = month_exp.groupby("Category")["Amount"].sum()
        cards, summary_html = insights.build_budget_progress_html(budgets, cat_spent)
        for card in cards:
            st.markdown(card, unsafe_allow_html=True)
        st.markdown(summary_html, unsafe_allow_html=True)

    st.markdown("---")
    st.subheader("📋 Recent Transactions")
    show = [c for c in ["Date","Transaction Type","Category","Amount","Account Name","Note"]
            if c in df.columns]
    st.dataframe(df[show].sort_values("Date", ascending=False).head(15),
                 use_container_width=True)


def pf_add():
    page_header("➕ Add Transaction", "Tracker › Add Transaction")
    uid = st.session_state.username
    st.markdown("""<div style="background:#FFFFFF;border:3px solid #F9A8D4;border-radius:22px;
        padding:28px 36px;box-shadow:0 6px 28px rgba(249,168,212,.2);margin-bottom:2rem;">
    """, unsafe_allow_html=True)

    c1, c2 = st.columns(2)
    with c1:
        txn_date = st.date_input("📅 Date", value=date.today())
        txn_type = st.selectbox("💳 Type", ["debit", "credit"])
        txn_cat  = st.selectbox("🏷️ Category", CATS)
    with c2:
        txn_amt  = st.number_input("💰 Amount (₹)", min_value=0.0, step=10.0, format="%.2f")
        txn_acct = st.text_input("🏦 Account Name", placeholder="e.g. HDFC Savings, GPay")
        txn_note = st.text_input("📝 Note (optional)")

    if st.button("✅ Save Transaction", use_container_width=True):
        if txn_amt <= 0:
            st.error("Amount must be greater than 0.")
        elif not txn_acct.strip():
            st.error("Account name is required.")
        else:
            db_add_txn(uid, txn_date, txn_type, txn_cat, txn_amt,
                       txn_acct.strip(), txn_note.strip())
            invalidate_cache()
            st.success(f"✅ {txn_type.capitalize()} of ₹{txn_amt:,.2f} saved!")
            st.rerun()

    st.markdown("</div>", unsafe_allow_html=True)


def pf_edit():
    page_header("✏️ Edit / Delete", "Tracker › Edit & Delete")
    uid   = st.session_state.username
    db_df = db_get_txns(uid)
    if db_df.empty:
        empty_state("🗂️", "No transactions yet", "Add some from ➕ Add Transaction first.")
        return

    st.subheader("🔍 Filter Transactions")
    f1, f2, f3, f4 = st.columns(4)
    with f1: f_type = st.selectbox("Type", ["All","credit","debit"], key="ef_type")
    with f2: f_cat  = st.selectbox("Category", ["All"] + CATS, key="ef_cat")
    with f3: f_acct = st.text_input("Account contains", key="ef_acct")
    with f4:
        years = sorted(db_df["Date"].str[:4].dropna().unique().tolist())
        f_yr  = st.selectbox("Year", ["All"] + years, key="ef_yr")

    fdf = filter_df(db_df, f_type, f_cat, f_acct, f_yr)
    st.markdown(f"**{len(fdf)} transaction(s) found**")
    show = [c for c in ["id","Date","Transaction Type","Category","Amount","Account Name","Note"]
            if c in fdf.columns]
    st.dataframe(fdf[show].head(50), use_container_width=True)

    st.markdown("---")
    tab_edit, tab_del = st.tabs(["✏️ Edit a Transaction", "🗑️ Delete"])

    with tab_edit:
        ids = fdf["id"].tolist() if "id" in fdf.columns else []
        if not ids:
            st.info("No transactions match the current filter.")
        else:
            sel_id = st.selectbox("Select transaction ID to edit", ids, key="edit_sel")
            row    = db_df[db_df["id"] == sel_id].iloc[0]
            st.markdown("""<div style="background:#FFFFFF;border:3px solid #C4B5FD;
                border-radius:20px;padding:20px 28px;
                box-shadow:0 6px 24px rgba(196,181,253,.2);margin-top:1rem;">
            """, unsafe_allow_html=True)
            ec1, ec2 = st.columns(2)
            with ec1:
                e_date = st.date_input("📅 Date",
                         value=pd.to_datetime(row["Date"]).date(), key="e_date")
                e_type = st.selectbox("💳 Type", ["debit","credit"],
                         index=0 if row["Transaction Type"]=="debit" else 1, key="e_type")
                e_cat  = st.selectbox("🏷️ Category", CATS,
                         index=CATS.index(row["Category"]) if row["Category"] in CATS else 0,
                         key="e_cat")
            with ec2:
                e_amt  = st.number_input("💰 Amount (₹)", value=float(row["Amount"]),
                         min_value=0.0, step=10.0, format="%.2f", key="e_amt")
                e_acct = st.text_input("🏦 Account Name",
                         value=str(row.get("Account Name","")), key="e_acct")
                e_note = st.text_input("📝 Note",
                         value=str(row.get("Note","")), key="e_note")
            if st.button("💾 Save Changes", use_container_width=True):
                if e_amt <= 0:
                    st.error("Amount must be > 0.")
                elif not e_acct.strip():
                    st.error("Account name required.")
                else:
                    db_update_txn(sel_id, e_date, e_type, e_cat, e_amt,
                                  e_acct.strip(), e_note.strip())
                    invalidate_cache()
                    st.success(f"✅ Transaction #{sel_id} updated!")
                    st.rerun()
            st.markdown("</div>", unsafe_allow_html=True)

    with tab_del:
        ids = fdf["id"].tolist() if "id" in fdf.columns else []
        if not ids:
            st.info("No transactions match.")
        else:
            d1, d2 = st.columns([2, 1])
            with d1:
                del_id = st.selectbox("Select ID to delete", ids, key="del_sel")
            with d2:
                st.markdown("<div style='height:28px'></div>", unsafe_allow_html=True)
                if st.button("🗑️ Delete This Row", use_container_width=True):
                    db_delete_txn(del_id)
                    invalidate_cache()
                    st.success(f"Deleted #{del_id}")
                    st.rerun()
        st.markdown("---")
        st.markdown("**⚠️ Danger zone**")
        if st.button("🗑️ Clear ALL My Transactions", type="primary"):
            db_clear_txns(uid)
            invalidate_cache()
            st.success("All transactions cleared.")
            st.rerun()


def pf_budgets():
    page_header("💰 Monthly Budgets", "Tracker › Monthly Budgets")
    uid = st.session_state.username
    sel_month = st.selectbox(
        "📅 Select Month",
        [date(date.today().year, m, 1).strftime("%Y-%m") for m in range(1, 13)],
        index=date.today().month - 1,
        format_func=lambda x: datetime.strptime(x, "%Y-%m").strftime("%B %Y"),
    )

    st.markdown("---")
    st.subheader("➕ Set a Budget")
    b1, b2, b3 = st.columns([2, 1, 1])
    with b1: b_cat = st.selectbox("Category", CATS, key="b_cat")
    with b2: b_amt = st.number_input("Budget (₹)", min_value=0.0, step=100.0,
                                      format="%.2f", key="b_amt")
    with b3:
        st.markdown("<div style='height:28px'></div>", unsafe_allow_html=True)
        if st.button("💾 Save Budget", use_container_width=True):
            if b_amt <= 0:
                st.error("Budget must be > 0.")
            else:
                db_set_budget(uid, sel_month, b_cat, b_amt)
                st.success(f"✅ {b_cat} → ₹{b_amt:,.2f}")
                st.rerun()

    st.markdown("---")
    budgets   = db_get_budgets(uid, sel_month)
    df        = get_df()
    month_exp = (df[(df["Transaction Type"] == "debit") & (df["Month Key"] == sel_month)]
                 if not df.empty else pd.DataFrame())
    cat_spent = (month_exp.groupby("Category")["Amount"].sum()
                 if not month_exp.empty else pd.Series(dtype=float))

    if budgets.empty:
        st.info(f"No budgets set for {datetime.strptime(sel_month,'%Y-%m').strftime('%B %Y')} yet.")
    else:
        st.subheader(f"📊 Budget vs Actual — {datetime.strptime(sel_month,'%Y-%m').strftime('%B %Y')}")
        cards, summary_html = insights.build_budget_progress_html(budgets, cat_spent)
        for card in cards:
            st.markdown(card, unsafe_allow_html=True)
        st.markdown(summary_html, unsafe_allow_html=True)

        chart_data = insights.build_budget_chart_data(budgets, cat_spent)
        if chart_data:
            from core.charts import bar_budget_vs_actual
            fig = bar_budget_vs_actual(chart_data)
            st.plotly_chart(fig, use_container_width=True, config={"displayModeBar": False})

        st.markdown("---")
        st.subheader("🗑️ Remove a Budget")
        del_cat = st.selectbox("Select category", budgets["category"].tolist(), key="del_bcat")
        if st.button("Remove Budget", key="del_budget_btn"):
            db_delete_budget(uid, sel_month, del_cat)
            st.success(f"Removed {del_cat}.")
            st.rerun()


def pf_history():
    page_header("📋 Transaction History", "Tracker › History")
    uid   = st.session_state.username
    db_df = db_get_txns(uid)
    if db_df.empty:
        empty_state("📋", "No transactions yet", "Start adding transactions to see history.")
        return
    st.subheader(f"📦 {len(db_df)} total transactions")
    show = [c for c in ["Date","Transaction Type","Category","Amount","Account Name","Note"]
            if c in db_df.columns]
    st.dataframe(db_df[show], use_container_width=True)


# ══════════════════════════════════════════════════════════════════
#  REPORTS PAGE
# ══════════════════════════════════════════════════════════════════

def pf_download():
    page_header("📥 Download Report", "Reports › Download")
    df = get_df()
    if df.empty:
        empty_state("📥", "Nothing to export", "Add transactions first.")
        return

    summary = analyzer_engine.build_export_summary(df)
    cat_bd  = analyzer_engine.build_category_export(df)

    buf = io.BytesIO()
    with pd.ExcelWriter(buf, engine="openpyxl") as w:
        cols = [c for c in ["Date","Transaction Type","Category","Amount","Account Name","Note"]
                if c in df.columns]
        df[cols].to_excel(w, sheet_name="Transactions", index=False)
        pd.DataFrame({
            "Metric": ["Total Income","Total Expense","Net Savings","Savings Rate %","Total Transactions"],
            "Value":  [summary["income"], summary["expenses"], summary["net"],
                       summary["savings_pct"], summary["total_transactions"]],
        }).to_excel(w, sheet_name="Summary", index=False)
        if not cat_bd.empty:
            cat_bd.to_excel(w, sheet_name="Category Breakdown", index=False)
    buf.seek(0)

    fname = (f"finance_report_{st.session_state.username}_"
             f"{datetime.today().strftime('%Y%m%d')}.xlsx")
    st.download_button(
        "📥 Download Excel Report", data=buf, file_name=fname,
        mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        use_container_width=True,
    )
    st.markdown("---")
    st.subheader("Preview")
    prev_cols = [c for c in ["Date","Transaction Type","Category","Amount","Account Name"]
                 if c in df.columns]
    st.dataframe(df[prev_cols].head(30), use_container_width=True)


# ══════════════════════════════════════════════════════════════════
#  PROFILE PAGE
# ══════════════════════════════════════════════════════════════════

def pf_profile():
    page_header("👤 My Profile", "Profile")
    uid  = st.session_state.username
    df   = get_df()
    mode = st.session_state.get("mode", "tracker")

    from core.metrics import calculate_savings_rate
    sr = calculate_savings_rate(df)

    st.markdown(f"""<div style="background:#FFFFFF;border:3px solid #F9A8D4;border-radius:22px;
        padding:28px 36px;box-shadow:0 8px 28px rgba(249,168,212,.2);margin-bottom:1.5rem;">
        <div style="font-size:3rem;margin-bottom:.75rem;">👤</div>
        <div style="font-size:1.5rem;font-weight:900;color:#be185d;">{uid}</div>
        <div style="color:#9d174d;font-weight:700;margin-top:4px;">
            Mode: <span style="background:#FFF0F9;border:2px solid #F9A8D4;border-radius:8px;
            padding:2px 10px;font-size:.88rem;">
            {'📝 Tracker + Analyzer' if mode=='tracker' else '📊 Analyzer only'}</span>
        </div>
        <div style="margin-top:1rem;display:grid;grid-template-columns:1fr 1fr 1fr;gap:12px;">
            <div style="background:#F0FDF4;border:2px solid #6EE7B7;border-radius:12px;
                padding:12px;text-align:center;">
                <div style="font-weight:900;font-size:1.4rem;color:#065f46;">{len(df)}</div>
                <div style="font-size:.78rem;font-weight:700;color:#6b7280;">Transactions</div>
            </div>
            <div style="background:#FFF0F9;border:2px solid #F9A8D4;border-radius:12px;
                padding:12px;text-align:center;">
                <div style="font-weight:900;font-size:1.4rem;color:#be185d;">₹{sr['income']:,.0f}</div>
                <div style="font-size:.78rem;font-weight:700;color:#6b7280;">Total Income</div>
            </div>
            <div style="background:#EFF6FF;border:2px solid #93C5FD;border-radius:12px;
                padding:12px;text-align:center;">
                <div style="font-weight:900;font-size:1.4rem;color:#1d4ed8;">₹{sr['expenses']:,.0f}</div>
                <div style="font-size:.78rem;font-weight:700;color:#6b7280;">Total Expenses</div>
            </div>
        </div>
    </div>""", unsafe_allow_html=True)

    st.markdown("---")
    st.subheader("🔄 Switch Mode")
    st.info("Switch between Tracker+Analyzer and Analyzer-only mode.")
    c1, c2 = st.columns(2)
    with c1:
        if st.button("📝 Enable Tracker + Analyzer", use_container_width=True,
                     disabled=(mode == "tracker")):
            st.session_state.mode = "tracker"
            st.rerun()
    with c2:
        if st.button("📊 Switch to Analyzer Only", use_container_width=True,
                     disabled=(mode == "analyzer")):
            st.session_state.mode = "analyzer"
            st.rerun()

    st.markdown("---")
    st.subheader("📂 Re-import Excel Data")
    st.warning("This will ADD new rows from a new Excel file to your existing database.")
    reimport_file = st.file_uploader("Upload Excel (.xlsx)", type=["xlsx"], key="profile_reimport")
    if reimport_file:
        try:
            rdf = pd.read_excel(reimport_file)
            rdf.columns = rdf.columns.str.strip()
            missing = [c for c in ["Date","Transaction Type","Category","Amount"]
                       if c not in rdf.columns]
            if missing:
                st.error(f"Missing columns: {', '.join(missing)}")
            else:
                if "Account Name" not in rdf.columns:
                    rdf["Account Name"] = "Reimported"
                st.success(f"Loaded {len(rdf)} rows.")
                if st.button("💾 Import into Database", key="profile_do_reimport"):
                    count = db_import_txns(uid, rdf)
                    invalidate_cache()
                    st.success(f"✅ {count} rows imported.")
                    st.rerun()
        except Exception as e:
            st.error(f"Could not read file: {e}")


# ══════════════════════════════════════════════════════════════════
#  PLATFORM — sidebar + routing
# ══════════════════════════════════════════════════════════════════

def page_platform():
    st.markdown("""<style>
    [data-testid="stSidebar"] { display:flex!important; }
    html,body,.stApp,[data-testid="stAppViewContainer"],
    [data-testid="stAppViewBlockContainer"],.main {
        background:linear-gradient(150deg,#FFF0F9 0%,#EFF6FF 40%,#F0FDF4 100%)!important; }
    .block-container { padding:0 2rem 3rem!important; max-width:1100px; }
    [data-testid="baseButton-primary"] {
        background:linear-gradient(90deg,#f472b6,#a78bfa)!important;
        box-shadow:0 2px 14px rgba(244,114,182,.4)!important; }
    [data-testid="baseButton-secondary"] {
        background:rgba(255,255,255,.8)!important;
        color:#9d174d!important; -webkit-text-fill-color:#9d174d!important;
        border:2px solid rgba(249,168,212,.5)!important; }
    </style>""", unsafe_allow_html=True)

    render_topbar()
    render_sidebar()

    section = st.session_state.nav_section
    page    = st.session_state.nav_page
    mode    = st.session_state.get("mode", "tracker")

    # ── Route tables ──────────────────────────────────────────
    ANALYZER_ROUTES = {
        "analytics":  pf_analytics,
        "insights":   pf_insights,
        "health":     pf_health,
        "charts":     pf_charts,
        "savings":    pf_savings,
        "categories": pf_categories,
    }
    TRACKER_ROUTES = {
        "overview": pf_overview,
        "add":      pf_add,
        "edit":     pf_edit,
        "budgets":  pf_budgets,
        "history":  pf_history,
    }
    REPORTS_ROUTES = {"download": pf_download}
    PROFILE_ROUTES = {"profile":  pf_profile}
    all_routes = {**ANALYZER_ROUTES, **TRACKER_ROUTES, **REPORTS_ROUTES, **PROFILE_ROUTES}

    # Guard: analyzer-only users cannot reach tracker pages
    if mode == "analyzer" and section == "tracker":
        nav("analyzer", "analytics")
        return

    fn = all_routes.get(page, pf_analytics)
    fn()


# ══════════════════════════════════════════════════════════════════
#  MAIN ROUTER
# ══════════════════════════════════════════════════════════════════
APP_PAGE = st.session_state.app_page

if not st.session_state.logged_in or APP_PAGE == "auth":
    page_auth()
elif APP_PAGE == "onboard_upload":
    page_onboard_upload()
elif APP_PAGE == "onboard_consent":
    page_onboard_consent()
elif APP_PAGE == "platform":
    page_platform()
else:
    page_auth()
