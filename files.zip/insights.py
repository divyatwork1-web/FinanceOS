"""
core/insights.py
══════════════════════════════════════════════════════════════════
Narrative insight builders for the Analyzer.
Functions return HTML strings or plain dicts that Streamlit pages
render.  No Streamlit imports — pure logic.
"""
from __future__ import annotations

import pandas as pd

from core.metrics import (
    analyze_category_trends,
    calculate_financial_health,
    generate_spending_insights,
    monthly_savings,
)

MONTHS = [
    "January", "February", "March", "April", "May", "June",
    "July", "August", "September", "October", "November", "December",
]


def build_smart_tip_html(tip: str) -> str:
    """Returns an HTML card containing the smart tip string."""
    return f"""<div style="background:#FFFFFF;border:3px solid #FCD34D;border-radius:22px;
        padding:20px 28px;box-shadow:0 6px 28px rgba(252,211,77,.25);
        font-size:1.1rem;font-weight:800;color:#1A1A2E;">{tip}</div>"""


def build_health_status_html(health: dict) -> str:
    """Returns the health status banner HTML."""
    return f"""<div style="background:#FFFFFF;border:3px solid #6EE7B7;border-radius:22px;
        padding:28px 36px;margin-bottom:1.5rem;box-shadow:0 8px 32px rgba(110,231,183,.2);">
        <div style="font-size:.78rem;font-weight:900;text-transform:uppercase;
            letter-spacing:.1em;color:#9d174d;margin-bottom:8px;">Overall Status</div>
        <div style="font-size:2rem;font-weight:900;color:{health['color']};">{health['label']}</div>
        <div style="color:#6b7280;font-weight:700;margin-top:4px;">
            Savings rate: {health['savings_pct']:.1f}% &nbsp;|&nbsp; Net: ₹{health['net']:,.0f}</div>
    </div>"""


def build_budget_progress_html(budgets: pd.DataFrame, cat_spent: pd.Series) -> list[str]:
    """
    Returns a list of HTML strings (one per budget row) for budget progress bars.
    Also returns a summary dict as the last element.
    """
    cards = []
    total_budget = 0.0
    total_spent = 0.0

    for _, brow in budgets.iterrows():
        cat = brow["category"]
        budget = float(brow["budget"])
        spent = float(cat_spent.get(cat, 0))
        pct = min(spent / budget * 100, 100) if budget > 0 else 0
        over = spent > budget
        bc = "#FCA5A5" if over else "#6EE7B7"
        lc = "#b91c1c" if over else "#15803d"
        status = (
            f"⚠️ Over by ₹{spent - budget:,.0f}"
            if over
            else f"✅ ₹{budget - spent:,.0f} left"
        )
        total_budget += budget
        total_spent += spent
        cards.append(
            f"""<div style="background:#FFFFFF;border:2px solid #F9A8D4;
                border-radius:14px;padding:12px 18px;margin:6px 0;">
                <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:5px;">
                    <span style="font-weight:900;font-size:1.02rem;">{cat}</span>
                    <span style="font-weight:800;color:{lc};font-size:.9rem;">{status}</span>
                </div>
                <div style="background:#F3F4F6;border-radius:8px;height:13px;overflow:hidden;">
                    <div style="width:{pct:.1f}%;background:{bc};height:100%;border-radius:8px;"></div>
                </div>
                <div style="display:flex;justify-content:space-between;margin-top:3px;
                    font-size:.8rem;font-weight:700;color:#9d174d;">
                    <span>₹{spent:,.0f} spent</span><span>of ₹{budget:,.0f} ({pct:.0f}%)</span>
                </div>
            </div>"""
        )

    o_pct = total_spent / total_budget * 100 if total_budget > 0 else 0
    o_over = total_spent > total_budget
    summary_html = f"""<div style="background:#FFFFFF;border:3px solid #C4B5FD;
        border-radius:16px;padding:14px 22px;margin-top:14px;
        box-shadow:0 4px 18px rgba(196,181,253,.3);">
        <div style="font-weight:900;color:#7c3aed;margin-bottom:3px;">📦 Overall Budget</div>
        <div style="font-size:1.1rem;font-weight:800;color:#{'b91c1c' if o_over else '15803d'};">
            ₹{total_spent:,.0f} of ₹{total_budget:,.0f} ({o_pct:.1f}%)</div>
    </div>"""

    return cards, summary_html


def build_budget_chart_data(budgets: pd.DataFrame, cat_spent: pd.Series) -> list[dict]:
    """Returns list of dicts for bar_budget_vs_actual chart."""
    data = []
    for _, brow in budgets.iterrows():
        cat = brow["category"]
        data.append({"Category": cat, "Amount": float(cat_spent.get(cat, 0)), "Type": "Spent"})
        data.append({"Category": cat, "Amount": float(brow["budget"]), "Type": "Budget"})
    return data


def build_pie_data(cat_df: pd.DataFrame) -> pd.DataFrame:
    """
    Takes top-10 category df (Category, Amount),
    collapses tail into 'Others' for a 5+1 slice pie.
    """
    if cat_df.empty:
        return cat_df
    top5 = cat_df.head(5)
    others_amt = cat_df["Amount"].iloc[5:].sum()
    import pandas as _pd
    return _pd.concat(
        [top5, _pd.DataFrame({"Category": ["Others"], "Amount": [others_amt]})],
        ignore_index=True,
    )
